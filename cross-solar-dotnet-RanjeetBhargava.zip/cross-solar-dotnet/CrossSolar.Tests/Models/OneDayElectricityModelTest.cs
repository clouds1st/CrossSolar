using System;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using CrossSolar.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CrossSolar.Tests.Models
{
    public class OneDayElectricityModelTest
    {
        
        public OneDayElectricityModelTest()
        {
         //var odeModel=new List<OneDayElectricityModel>();   
         // Assert.NotNull(odeModel);
        }
      
    }
}