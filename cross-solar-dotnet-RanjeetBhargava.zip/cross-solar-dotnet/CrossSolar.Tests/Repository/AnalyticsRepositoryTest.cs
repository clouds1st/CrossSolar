using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using CrossSolar.Controllers;
using CrossSolar.Domain;
using CrossSolar.Models;
using CrossSolar.Repository;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CrossSolar.Tests.Repository
{
    public class AnalyticsRepositoryTests
    {
        private readonly Mock<CrossSolarDbContext> dbContextMoc;
        private  Mock<AnalyticsRepository> analyticsRepository;
        public AnalyticsRepositoryTests()
                {
                    analyticsRepository = new Mock<AnalyticsRepository>(dbContextMoc.Object);
                   // Assert.NotNull(analyticsRepository);
                }
    }
    
}