using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using CrossSolar.Controllers;
using CrossSolar.Domain;
using CrossSolar.Models;
using CrossSolar.Repository;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CrossSolar.Tests.Controller
{
    public class AnalyticsControllerTests
    {
        public AnalyticsControllerTests()
        {
            _analyticsController = new AnalyticsController(_analyticsRepositoryMock.Object,_panelRepositoryMock.Object);
        }

        private readonly AnalyticsController _analyticsController;
        private readonly Mock<IPanelRepository> _panelRepositoryMock=new Mock<IPanelRepository>();
        private readonly Mock<IAnalyticsRepository> _analyticsRepositoryMock = new Mock<IAnalyticsRepository>();
        private readonly Mock<CrossSolarDbContext> _dbContext = new Mock<CrossSolarDbContext>();
     //   private readonly Mock<IGenericRepository> _genericRepositoryMock=new Mock<IGenericRepository>(It.IsAny<T>());
        [Fact]
        public async Task Get_ShouldReturnOneHourElectricityListModel()
        {
        // var panel = (new List<PanelModel> plist{  new PanelModel
        //     {
        //         Brand = "Areva",
        //         Latitude = 12.345678,
        //         Longitude = 98.7655432,
        //         Serial = "AAAA1111BBBB2222"
        //     }}
        //     select plist).AsQueryable();
            //     _panelRepositoryMock.Setup(repo => repo.Query()).Returns((new Iqueryable<PanelModel>() {  new PanelModel
            // {
            //     Brand = "Areva",
            //     Latitude = 12.345678,
            //     Longitude = 98.7655432,
            //     Serial = "AAAA1111BBBB2222"
            // }}
            // ) );
            // string panelId="abc"; //[FromRoute]
            // var resultList =  new OneHourElectricityModel
            //     {
            //         Id = 10,
            //         KiloWatt =5000,
            //         DateTime =System.DateTime.Now
            //     };
           
            // _analyticsRepositoryMock.Setup(repo => repo.Query().Where(x => x.PanelId.Equals(panelId, StringComparison.CurrentCultureIgnoreCase))).Returns(resultList);
           
           var result = await _analyticsController.Get("abc");//panelId
           
            Assert.NotNull(result);
           var createdResult = result as CreatedResult;
           Assert.NotNull(createdResult);
           Assert.Equal(201, createdResult.StatusCode);
           //Assert.Equal(1,1);

        }

        [Fact]
         public async Task DayResults_ShouldReturnOneDayElectricityModelListModel()
        {
            //var resultLst = new List<OneDayElectricityModel>();
            var result = await _analyticsController.DayResults("abc");
            Assert.NotNull(result);

            var createdResult = result as CreatedResult;
            Assert.NotNull(createdResult);
            Assert.Equal(201, createdResult.StatusCode);
        }

         [Fact]
        public async Task Post_ShouldReturnInsetedPanelId()
        {
           // if (!ModelState.IsValid) return BadRequest(ModelState);

            var oneHourElectricityContent = new OneHourElectricity
            {
                PanelId = "12",
                KiloWatt = 5000,
                DateTime = System.DateTime.UtcNow
            };
            var emodel= new OneHourElectricityModel{
               Id = 12, //oneHourElectricityContent.PanelId,
                KiloWatt = oneHourElectricityContent.KiloWatt,
                DateTime = oneHourElectricityContent.DateTime
            };
           // _dbContext.Setup(c => c.SaveChangesAsync()).Returns(oneHourElectricityContent).Verifiable();//() => Task.Run(() =>{}
           // _genericRepositoryMock.Setup(a=>a.InsertAsync()).Returns(oneHourElectricityContent, _dbContext);
          //  _analyticsRepositoryMock.Setup(a=>a.InsertAsync()).Returns(oneHourElectricityContent, _dbContext);
           // await _analyticsRepository.InsertAsync(oneHourElectricityContent);
             //_analyticsRepositoryMock.Setup(repo => repo.InsertAsync(oneHourElectricityContent)).Returns(oneHourElectricityContent);
             //var actual = await _analyticsRepositoryMock.InsertAsync(oneHourElectricityContent, _dbContext);
             var result=await _analyticsController.Post(oneHourElectricityContent.PanelId,emodel);
            
            Assert.NotNull(result);
                    var createdResult = result as CreatedResult;
                    Assert.NotNull(createdResult);
                    Assert.Equal(201, createdResult.StatusCode);
        }
    }
}