﻿using CrossSolar.Domain;

namespace CrossSolar.Repository
{
    public interface IPanelRepository : IGenericRepository<Panel>
    {
    }
}